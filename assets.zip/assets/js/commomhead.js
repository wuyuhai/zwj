var url = document.location.toString();
var ziduan = "",ziduan2="";　


if(!localStorage.getItem('allareaarr')){
	var sdhsaddata = {
			pageNum: 1,
          	pageSize: 10000				
		};

	$.ajax('https://gzzw.gzegn.gov.cn:84/UrbanService/region/getRegions',{
		data:JSON.stringify(sdhsaddata),
		dataType: 'json', //服务器返回json格式数据
		contentType:"application/json",
		timeout: 10000,
		type: 'post', //HTTP请求类型
		success: function (data) {
			//服务器返回响应，根据响应结果，分析是否登录成功；
			console.log(data)
			if(data.code == 200) {
				localStorage.allareaarr= JSON.stringify(data.data);
			} else {
				errsoletishi(data.msg)
			}
		},
		error: function () {
//			alert("请求错误")
			errsoletishi("请求错误")
		},
		complete: function(status){ //请求完成后最终执行参数
			if(status=='timeout'){
				errsoletishi('请求超时！')
			}
		},
	});
}


if(url.indexOf("/new/")!=-1){
	ziduan += "../../";
}else if(url.indexOf("/bmcx/")!=-1){
	ziduan += "../../../"
}else{
	ziduan += "../"
	ziduan2 += "new/"
}

if(url.indexOf("newlogin")!=-1){
	var newht = ""
}else{			
	var newht = '<a href="'+ziduan2+'newlogin.html" style="color:#fff;">'+
					'<div v-show="showone==true" class="n_wydls">'+					
						'登录'+						
					'</div>'+
				'</a>'+	
				'<div v-show="showtwo==true" class="n_tcdls" @click="tuichuuser">'+
					'退出'+
				'</div>';
}

$(".n_nav_head").append(newht)
$(".index_header").append('<img class="index_logo" src="'+ziduan +'assets/img/n_logo.png"/>'+
				'<div class="index_titandarea">'+
					'<p>{{titlearea}}政务服务自动终端系统</p>'+
					'<div>'+
						'<img src="'+ziduan +'assets/img/newindex/n_ts2.png"/>'+
					'</div>'+
				'</div>'+
				'<div class="index_titandarea_area" @click="areachange()">'+
					'<img src="'+ziduan +'assets/img/new/dd.png"/>'+
					'<p>{{nowxuanze}}<br><span>[切换地区]</span></p>'+
				'</div>'+		
				'<div v-show="showtwo==true" class="index_sheyutime">'+
					'<p><span style="color: #fff45c;margin-right: 7.5px;">{{shengyutime}}</span>秒</p>'+
				'</div>');
				

//if(url.indexOf("index.html")==-1){
	$(".index_box").append('<div class="index_footer">技术支持: 贵州方图云数科技有限公司'+
					'<div v-if="showtwo==true" class="index_perple">'+
						'欢迎{{userinfo.REALNAME}}登录!'+
					'</div></div>')
//}else{
//	$(".index_box").append('<div class="index_footer">技术支持: 贵州方图云数科技有限公司<span style="color:#2296e9">图云数科技有</span>网址: www.fotoit.com</div>')
//}

$(".index_box").append('<div id="areaxuanze" v-bind:class="areachangebol?\'display_show\':\'display_no\'">'+
				'<div class="areaxuanze_zz" @click="areachangeclose()"></div>'+
				'<div class="areaxuanze_kuang">'+
					'<div class="areaxuanze_kuang_h">'+
						'请选择区划'+
						'<div class="close" @click="areachangeclose()">'+
							'<Icon size="32" type="ios-close" />'+
						'</div>'+				
					'</div>'+
					'<div class="areaxuanze_kuang_shi">'+
						'<ul>'+
							'<li @click="clickshicur($event,\'520100\',\'贵阳市\')">'+
								'贵阳市'+
							'</li>'+
							'<li @click="clickshicur($event,\'520200\',\'六盘水市\')">'+
								'六盘水市'+
							'</li>'+
							'<li @click="clickshicur($event,\'520300\',\'遵义市\')">'+
								'遵义市'+
							'</li>'+
							'<li @click="clickshicur($event,\'520400\',\'安顺市\')">'+
								'安顺市'+
							'</li>'+
							'<li @click="clickshicur($event,\'520500\',\'毕节市\')">'+
								'毕节市'+
							'</li>'+
							'<li @click="clickshicur($event,\'520555\',\'贵安新区\')">'+
								'贵安新区'+
							'</li>'+
							'<li @click="clickshicur($event,\'520600\',\'铜仁市\')">'+
								'铜仁市'+
							'</li>'+
							'<li @click="clickshicur($event,\'522300\',\'黔西南州\')">'+
								'黔西南州'+
							'</li>'+
							'<li @click="clickshicur($event,\'522600\',\'黔东南州\')">'+
								'黔东南州'+
							'</li>'+
							'<li @click="clickshicur($event,\'522700\',\'黔南州\')">'+
								'黔南州'+
							'</li>'+
							'<li @click="clickshicur($event,\'520000\')">'+
								'省本级'+
							'</li>'+
						'</ul>'+
					'</div>'+
					'<div class="areaxuanze_kuang_qu">'+
						'<ul>'+
							'<li v-for="item in areas" @click="clickshiqu($event,item.areaid)">'+
								'{{item.name}}'+
							'</li>'+
						'</ul>'+
					'</div>'+
					'<div class="areaxuanze_kuang_foot">'+
						'<div class="one">'+
							'<span>当前选择</span>'+
							'{{ nowxuanze}}'+
						'</div>'+
						'<div class="two" @click="areachangeclose()">取消</div>'+
						'<div class="three" @click="areachangeclose()">确认</div>'+
					'</div>'+
				'</div>'+
			'</div>')

//$('.index_box').append('<div class="errsoelts">'+
//				'<div class="errsoelts_zz" @click="tipzidsure"></div>'+
//				'<div class="errsoelts_box">'+
//					'<h5>系统提示</h5>'+
//					'<div class="tipzid">'+
//						'<p>{{tisjiconttxt}}!</p>'+
//						'<div class="tipzid_sure" @click="tipzidsure">确定</div>'+
//					'</div>'+
//				'</div>'+
//			'</div>');

sessionStorage.guanjitime = ft.getConfig("关机时间");
sessionStorage.qingxidu = ft.getConfig("清晰度");

window.onload = function () {
//	document.oncontextmenu = function () { return false; }
//	document.onselectstart = function () { return false; }
//	document.onselect = function () { return false; }
//	
//	document.onkeydown = function (key) {
//	    if (key.keyCode == 123 && key.ctrlKey) {
//	        ft.showDevTools();
//	    }
//	}
}	
