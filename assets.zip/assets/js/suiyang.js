//获取摄像头ID
function getCameraIdByCameraName(name, ok, fail) {
    // 获取本机设备（麦克风，摄像头，音频设备）列表，并通过kind和lable可以筛选出想要的设备deviceId
    navigator.mediaDevices.enumerateDevices().then(function (deviceInfos) {
        console.log(deviceInfos);
        for (let i = 0; i < deviceInfos.length; i++) {
            const element = deviceInfos[i];
            if (element.kind == 'videoinput' && element.label.indexOf(name) != -1) {
                ok(element.deviceId);
                return;
            }
        }
        fail("无设备");
    })
}

//通过H5打开摄像头
function openCameraByH5(divDom, cameraName, onFace,isCheckFace,kind) {	
	if (isCheckFace == undefined){
		isCheckFace = true;
	} 
    var width = $(divDom)[0].offsetWidth
    var height = $(divDom)[0].offsetHeight
	
	canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    context = canvas.getContext("2d");

	videoDom = document.createElement("video");

	faceBox = document.createElement("div");

    videoDom.style.position = "absolute";
    videoDom.style.width = "100%";
    videoDom.style.height = "100%";
    videoDom.style.objectFit = "fill";
    faceBox.style.position = "absolute";
    faceBox.style.border = "2px solid #0f0";
    faceBox.style.width = "100%";
    faceBox.style.height = "100%";
    divDom.appendChild(videoDom);
    divDom.appendChild(faceBox);
	
    getCameraIdByCameraName(cameraName,	
        function (deviceId) {
//      	var newcs = sextqxd(sessionStorage.getItem("qingxidu")); 
//      	var newcs = sextqxd(3264); 
        	console.log(deviceId)
            var constraints = {
                video: {
                    deviceId: deviceId,
                }
            };
			
			if(isCheckFace == false && kind != undefined){
				var newcs = sextqxd(sessionStorage.getItem("qingxidu")); 
				constraints.video.width = newcs.width;
				constraints.video.height = newcs.height;
			}
			
            // -> 此处可以加上打开摄像头的动画
            window.navigator.mediaDevices.getUserMedia(constraints).then(function (mediaStream) {
                console.log("正在打开摄像头");
                stream = mediaStream;
                videoDom.srcObject = mediaStream;

                videoDom.onloadedmetadata = function () {
                    console.log("播放显示到Video");
                    // -> 此处可以关闭摄像头的动画
                    videoDom.play();
                    if(isCheckFace == false){
                    	if(kind == 1){
                    		faceBox.style.left = 240 + "px";
	                        faceBox.style.top = 30 + "px";
	                        faceBox.style.width = 390 + "px";
	                        faceBox.style.height = 535 + "px";
	                        faceBox.style.display = "inline-block";
                    	}      
                    	if(kind == 2){
                    		faceBox.style.left = 330 + "px";
	                        faceBox.style.top = 420 + "px";
	                        faceBox.style.width = 165 + "px";
	                        faceBox.style.height = 105 + "px";
	                        faceBox.style.display = "inline-block";
                    	} 
                    }
                    // console.log(getBase64(1440, 900, true))
                };
                if (isCheckFace && canvas && context) {
                    _outputCameraTimeInterval = setInterval(() => {
                        // 从视频中绘制出一张视频帧图片
                        context.drawImage(videoDom, 0, 0, width, height);
                        var base64 = canvas.toDataURL("image/png", 1).replace("data:image/png;base64,", "");
                        var postimg = canvas.toDataURL("image/png", 1);
                        // 通过base64图片查找人脸
                        console.log(postimg)
                        var faces = JSON.parse(ft.faceCheck(base64));
//                      console.log(faces);
                        onFace(faces,postimg,base64);

                        // 显示人脸位置
                        if (faces.length > 0) {
                        	if(faceBox){
                        		faceBox.style.left = faces[0].left + "px";
	                            faceBox.style.top = faces[0].top + "px";
	                            faceBox.style.width = faces[0].width + "px";
	                            faceBox.style.height = faces[0].height + "px";
	                            faceBox.style.display = "inline-block";
                        	}                           
                        } else {
                            faceBox.style.display = "none";
                        }
                    }, 0);
                }
            }).catch(function (e) {
                console.log(e);
                console.log("打开摄像头失败");
                errsoletishi('打开摄像头失败！')
            })
        },
        function (msg) {
            console.log(msg);
            errsoletishi(msg)
        });
}

//拍摄，返回base64
function getBase64(data, success, fail) {
    var e = {
        "msg": "",
        "data": ""
    };
    var dataParams = data;
    type = dataParams.type;
    if (!videoDom) {
        e.msg = "未打开摄像头"
        if (fail) {
            fail(e);
        }
    }
    if (!canvas || !context) {
        if (fail) {
            fail(e);
        }
        return;
    }
    var newcs = sextqxd(sessionStorage.getItem("qingxidu"));
//  var newcs = sextqxd(3264);
    var bili = newcs.width / 3264;
    console.log(newcs)
    console.log(dataParams)
    if(dataParams.kind == 1){
    	context.drawImage(videoDom,900 * bili,195 * bili,1540 * bili,4800 * bili,0,0,900,1400)
    }
    if(dataParams.kind == 2){
    	context.scale(3,3)
    	context.drawImage(videoDom,1242* bili,1700* bili,1285* bili,4540* bili,0,0,600,1950)
    }  
    if(dataParams.kind == 3){
    	context.drawImage(videoDom,0,0,canvas.width,canvas.height)
    }
    var base64 = canvas.toDataURL("image/png", 1);
    e.msg = "拍摄成功";
    if (type) {
        e.data = base64;
    } else {
        e.data = base64.replace("data:image/png;base64,", "");
    }
    if (success) {
        success(e);
    }
}

//关闭摄像头
function closeCamera(success, fail,isCheckFace) {
	if (isCheckFace == undefined){
		isCheckFace = true;
	}
    var e = {
        "msg": "",
        "data": ""
    };
    // 关闭摄像头
     var videoDom = document.getElementsByTagName("video")[0];
    if (videoDom) {
        if (stream) {
        	if(isCheckFace){
        		window.clearInterval(_outputCameraTimeInterval);
            	
        	}           
            stream.getTracks()[0].stop();
            stream = null;
			videoDom.remove();
			faceBox.remove();
//          videoDom.parentNode.removeChild(videoDom);
//          faceBox.parentNode.removeChild(faceBox);
//          videoDom = null;
//          faceBox = null;
			
            canvas = null;
            context = null;
            e.msg = "关闭摄像头成功";
            if (success) {
                success(e);
            }
        }
    } else {
        e.msg = "未打开摄像头";
        if (fail) {
            fail(e);
        }
    }
}

function isEndWith(sourceStr, endStr) {
    var d = sourceStr.length - endStr.length;
    return (d >= 0 && sourceStr.lastIndexOf(endStr) == d);
}