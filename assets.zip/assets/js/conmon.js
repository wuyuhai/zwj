function page_back() {
	history.back(-1)
}

//身份证阅读器打开
function idCardydOpen() {
	ftIdCard.initCard({
		onCard: function(e) {
			console.log(e);
		},
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//身份证阅读器关闭
function idCardydClose() {
	ftIdCard.closeCard({
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//人脸识别打开
function ftFaceOpen() {
	ftFace.openFace({
		x: 400,
		y: 10,
		width: 640,
		height: 480,
		face: function(e) {
			if(!e.data.state != 1) {
				// 人脸不符合要求，进行提醒
			} else {
				if(faceArray.length < 3) {
					faceArray.push(e.data.facePhoto);
				} else {
					// 关闭摄像头
					// 拿到视频帧图片
				}
			}
		},
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//人脸识别关闭
function ftFaceClose() {
	ftFace.openFace({
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//获取摄像头列表
function ftGetCamera() {
	ftFace.getCamera({
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//pdf预览
function ftPdfPreview() {
	ftPrint.pdfPreview({
		x: 600,
		y: 10,
		width: 800,
		height: 800,
		pdfBase64: "...",
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//关闭pdf预览
function ftPdfPreviewClose() {
	ftPrint.closePdfPreview({
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//打印
//参数a:打印机类型：PHOTO、A4、TICKET(票据)
//参数b:打印类型：IMAGE、HTML、PDF
function printOpen(a, b) {
	ftPrint.print({
		printer: a,
		printType: b,
		fileBase64: "....",
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//签名版初始化
function ftInitSign() {
	ftSign.initSign({
		x: 600,
		y: 10,
		width: 400,
		height: 200,
		success: function(e) {
			console.log(e);
		},
		save: function(e) {
			console.log(e.data);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//保存签名
function ftSaveSign() {
	ftSign.saveSign({
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//关闭签名
function ftCloseSign() {
	ftSign.closeSign({
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//初始化复印
function ftDuplicateInit() {
	ftDuplicate.duplicateInit({
		x: 400,
		y: 10,
		width: 640,
		height: 480,
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//打开复印
//参数a:复印类型：A4、IDCARD
function ftDuplicateOpen(a) {
	ftDuplicate.duplicateOpen({
		duplicateType: a,
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//确认复印
function ftDuplicateSure() {
	ftDuplicate.duplicate({
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//关闭复印
function ftDuplicateClose() {
	ftDuplicate.duplicateClose({
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//打开指纹仪
function ftOpenFingerPrint() {
	ftFingerPrint.openFingerPrint({
		imageReceived: function(e) {
			console.log(e)
		},
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//指纹对比
function ftMatchFingerPrint() {
	ftFingerPrint.matchFingerPrint({
		destPF: ["...", "...", "..."],
		sourPF: "...",
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//关闭指纹仪
function ftCloseFingerPrint() {
	ftFingerPrint.closeFingerPrint({
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//打开HID设备
function ftOpenHid() {
	console.log(1)
	ftHid.openHid({
		vendorId: 1155, //HID设备的VID
		productId: 22352, //HID设备的PID
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//发送hid指令
function ftWriteHid() {
	ftHid.writeHid({
		command: [12, 12, 12, 170, 172, 15, 1, 221, 162],
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//读取hid
function ftReadHid() {
	ftHid.readHid({
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

//关闭hid
function ftCloseHid() {
	ftHid.closeHid({
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

function GetUrlParam(paraName) {　　　　
	var url = document.location.toString();　　　　
	var arrObj = url.split("?");　　　　
	if(arrObj.length > 1) {　　　　　　
		var arrPara = arrObj[1].split("&");　　　　　　
		var arr;　　　　　　
		for(var i = 0; i < arrPara.length; i++) {　　　　　　　　
			arr = arrPara[i].split("=");　　　　　　　　
			if(arr != null && arr[0] == paraName) {　　　　　　　　　　
				return arr[1];　　　　　　　　
			}　　　　　　
		}　　　　　　
		return "";　　　　
	}　　　　
	else {　　　　　　
		return "";　　　　
	}　　
}

function dataURLtoFile(dataurl, filename) { //将base64转换为文件
	var arr = dataurl.split(','),
		mime = arr[0].match(/:(.*?);/)[1],
		bstr = atob(arr[1]),
		n = bstr.length,
		u8arr = new Uint8Array(n);
	while(n--) {
		u8arr[n] = bstr.charCodeAt(n);
	}
	return new File([u8arr], filename, {
		type: mime
	});
}

function getTimenow() {
	var dd = new Date();
	var tmess = dd.toLocaleString('chinese', {
		hour12: false
	}).replace(/\//g, "").replace(" ", "").replace(/:/g, "");
	var tmes = "" + dd.getFullYear() + (dd.getMonth() + 1) + dd.getDate() + tmess.split(',')[1]
	var strmd5 = 'QUPQAMDBM' + 'LSHI8QKKCKLZCKMBXUK4' + tmes;
	return {
		strmd5: ft.getMd5(strmd5),
		time: tmes
	}
}

function loadingimg(k, c) {
	var ch = "";
	for(var i = 0; i < c; i++) {
		ch += '../'
	}
	if(k == 1) {
		$('body').append('<img class="loading_img" src="../' + ch + 'assets/img/loading.png"/>')
	}
	if(k == 2) {
		$('body').append('<img class="loading_img" src="../' + ch + 'assets/img/loading.gif"/>')
	}
}

function loadingimgremove() {
	$('.loading_img').remove()
}


var guanjibol = true;
function nowtime() {
	var myDate = new Date();
	var days = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
//	$(".index_footer").text(myDate.toLocaleString() + " " + days[myDate.getDay()])

	var gjstr = myDate.getHours() * 60 + myDate.getMinutes();
	//	console.log(gjstr)
	//	console.log(Number(sessionStorage.guanjitime.substr(0,2))*60 + Number(sessionStorage.guanjitime.substr(2,2)))
	if(sessionStorage.guanjitime && sessionStorage.guanjitime != "null") {

	} else {
		sessionStorage.guanjitime = 1730;
	}
//	console.log(sessionStorage.guanjitime)
	if(Number(gjstr)>(Number(sessionStorage.guanjitime.substr(0,2))*60 + Number(sessionStorage.guanjitime.substr(2,2)))){
		if(guanjibol == true){
			guanjibol = false;
			setTimeout(function(){				
				ft.shutDown();
			},60000)
		}						
	}
}

function longbuilding() {
	//	alert("系统正在建设中")
}

$(window).unbind('click').on('click',function(e) {
//	if(JSON.parse(localStorage.getItem('userinfo'))) {
		if($("#sel_li")[0]!=undefined){
			if(e.target.localName != "li"){
				if(e.target.className != "comselsect"){
					if($("#sel_li")[0].style.display != "none"){
						$("#sel_li").hide()
					}
				}			
			}		
		}
		hotItemsVue.tiemsr()
//	}
})

function resultjsonFun(a, b, c, d, urls) {
	var data = {
		"param": a,
		"errorMsg": b,
		"url": c,
		"type": d
	}
	$.ajax(urls, {
		data: JSON.stringify(data),
		dataType: 'json', //服务器返回json格式数据
		contentType: "application/json",
		timeout: 10000,
		type: 'post', //HTTP请求类型
		success: function(data) {
			console.log(data)
		},
		error: function() {
			//			alert("网络错误,请联系维护人员处理")
			errsoletishi("网络错误,请联系维护人员处理")
		},
		complete: function(status){ //请求完成后最终执行参数
			if(status=='timeout'){
				errsoletishi('请求超时！')
			}
		},
	});
}

function errsoletishi(p) {
	$('body').append('<div class="errsoelts">' +
		'<div class="errsoelts_zz" onclick="tipzidsurenew()"></div>' +
		'<div class="errsoelts_box">' +
		'<h5>系统提示</h5>' +
		'<div class="tipzid">' +
		'<p>' + p + '!</p>' +
		'<div class="tipzid_sure" onclick="tipzidsurenew()">确定</div>' +
		'</div>' +
		'</div>' +
		'</div>');
}

function tipzidsurenew() {
	$(".errsoelts").remove();
}

//打印
function ft_print(title, contont_div, classkind, style) {
	var $pthtml;
	console.log(contont_div)
	if(classkind == 1) {
		$pthtml = $("#" + contont_div);
	}
	if(classkind == 2) {
		$pthtml = $("." + contont_div)
	}
	console.log($pthtml)
	if($pthtml[0].style.display == "none") {
		errsoletishi("请先输入查询内容");
		return
	}
	var htmls = '<div class="prientpage">';
	if(style) {
		htmls += '<div class="prienthad2" id="prienthad">';
	} else {
		htmls += '<div class="prienthad" id="prienthad">';
	};
	if(title != "") {
		htmls += '<p class="juzti">' + title + '</p>';
	}
	htmls += '<div id="falvfagui" class="wenzhangtotal">' +
		'</div>' +
		'</div>' +
		'<div>' +
		'<div class="prientbtn" onclick="ft_sureprint()">' +
		'确认打印' +
		'</div>' +
		'<div class="prientbtncnacel" onclick="ft_hideprint()">' +
		'取消打印' +
		'</div>' +
		'</div>' +
		'</div>';
	$(".dw_box").hide();	
	$("body").append(htmls)
	$("#falvfagui").html($pthtml.html())
}

function htmlhide() {
	$(".dayinclass").show();
	$(".dayinclasstwo").show();
	$(".gonggongbiao").hide();
	$(".tishi_hide").hide()
}

function ft_hideprint() {
	$(".prientpage").remove();
	$(".dw_box").show();
}

function ft_sureprint() {
	$(".prientbtn").hide();
	$(".prientbtncnacel").hide();
	ft.printHtml({
		printer: sessionStorage.getItem('dayinji'),
		success: function(e) {
			errsoletishi("正在打印中，请稍后...")
			$(".prientbtn").show();
			$(".prientbtncnacel").show();
		},
		fail: function(e) {
			errsoletishi("该设备暂不支持打印")
			$(".prientbtn").show();
			$(".prientbtncnacel").show();
		}
	});
}

function rt_html() {
	$(".gonggongbiao").show();
	$(".tishi_hide").show();
	$(".chaxun_jieg").hide();
	$(".dw_box").show();
}

function selectfuc(e) {
	//	console.log(e)
	$(e).next().show();
}

function selectsurefuc(e, par) {
	$(e).parent().hide();
	//	console.log($(e).attr("value"))
	$(e).parent().prev().html($(e).html())
//	$("#" + par).html($(e).html());
	$("#" + par).attr("value", $(e).attr("value"));
}

function ft_printImage() {
	$("#newsprint").show()
}

function ft_sureprintimg() {
	ft.printImage({
		printer: sessionStorage.getItem('dayinji'),
		base64: document.getElementById("myCanvas").toDataURL().replace("data:image/png;base64,", ""),
		success: function(e) {
			console.log(e);
		},
		fail: function(e) {
			console.log(e);
		}
	});
}

function ft_hideprintimg() {
	$("#newsprint").hide()
}

function printImage(imgsrc, texttits,a,b,f,d) {
	var c = document.getElementById("myCanvas");
	var cxt = c.getContext("2d");

	var image = new Image();
	image.src = imgsrc;
	image.onload = function() {
		var ca = a?a:0;
		var cb = b?b:0;
		var cf = f?f:0;
		var cd = d?d:0;
		cxt.drawImage(image, ca, cb, c.width+cf, c.height+cd);
		
		var st = JSON.parse(texttits)
		var texttitsarr = st.arr;
		for(var i = 0; i < texttitsarr.length; i++) {
			if(texttitsarr[i].txt != "null") {
				cxt.font = st.fontweight + " " + st.size + "px " + st.fontfaily;
				if(texttitsarr[i].fz){
					cxt.font = st.fontweight + " " + texttitsarr[i].fz + "px " + st.fontfaily;
				}			
				cxt.textAlign = 'left';
				if(texttitsarr[i].hh){				
					var lhet = texttitsarr[i].lh?texttitsarr[i].lh:20;
					drawText(texttitsarr[i].txt, texttitsarr[i].width, texttitsarr[i].height, texttitsarr[i].hh,cxt,lhet)
				}else{
					cxt.fillText(texttitsarr[i].txt, texttitsarr[i].width, texttitsarr[i].height);
				}				
			}
		}
	}
}

function drawText(t, x, y, w,c,lineHeight) {
	var temp = "";
	var row = [];

	for(var a = 0; a < t.length; a++) {
		if(c.measureText(temp).width < w) {
			
		} else {
			row.push(temp);
			temp = "";
		}
		temp += t[a];
	}
	row.push(temp);
	for(var b = 0; b < row.length; b++) {
		c.fillText(row[b], x, y + (b + 1) * lineHeight);
	}
}

//正则
function zz_isCardNo(card)  {  
   var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;  
   if(reg.test(card) === false)  {  
       return  false;  
   }else{
   	return true
   }
}
function zz_isName(name)  {  
   var reg = /^[\u4E00-\u9FA5\uf900-\ufa2d·s]{2,20}$/;
   if(reg.test(name) === false)  {  
       return  false;  
   }else{
   	return true
   }
}

//视屏清晰度选择
function sextqxd(num) {
	var nums = 2048;
	if(num && num != "null") {
		nums = Number(num)
	}
	var bili = nums / 3264;
	var cnashu = {
		width: nums,
	}

	switch(nums) {
		case 3264:
			cnashu.height = 2448;
			break;
		case 2594:
			cnashu.height = 1944;
			break;
		case 2048:
			cnashu.height = 1536;
			break;
		case 1920:
			cnashu.height = 1080;
			break;
		case 1600:
			cnashu.height = 1200;
			break;
		case 1280:
			cnashu.height = 720;
			break;
		case 1024:
			cnashu.height = 768;
			break;
		case 800:
			cnashu.height = 600;
			break;
		case 640:
			cnashu.height = 480;
			break;
	}
	return cnashu;
}

function timeVs(startTiem,endTime){
	var s = startTiem.split("-"),e = endTime.split("-");
	var num1 = Number(s[0])*10000 + Number(s[1])*100 + Number(s[2]);
	var num2 = Number(e[0])*10000 + Number(e[1])*100 + Number(e[2]);
	if(num1 >= num2){
		return false;
	}else{
		return true;
	}
}

function ajaxPostFuc(url,headers,data,suc,fail,index){
	if(headers!=""){
		$.ajax({
			url: url,
			type: "POST",
			dataType: "json",
			headers: headers,
			timeout: 10000,
			data: data,
			success: function(e) {
				suc(e);
			},
			error: function (e) {
				fail(e)
			},
			complete: function(status){ //请求完成后最终执行参数
				if(status.statusText == 'timeout') {		
					layer.close(index);
					errsoletishi('请求超时！')
				}
			},
		})
	}else{
		$.ajax({
			url: url,
			type: "POST",
			dataType: "json",
			timeout: 10000,
			data: data,
			success: function(e) {
				suc(e);
			},
			error: function (e) {
				fail(e)
			},
			complete: function(status){ //请求完成后最终执行参数
				if(status.statusText == 'timeout') {	
					layer.close(index);
					errsoletishi('请求超时！')
				}
			},
		})
	}
	
}
function ajaxPostFucXml(url,headers,data,suc,fail,index){
	$.ajax({
		url: url,
		type: "POST",
		dataType: "json",
		headers: headers,
		timeout: 10000,
		data: data,
		success: function(e) {
			suc(e);
		},
		error: function (e) {
			fail(e)
		},
		complete: function(status){ //请求完成后最终执行参数
			if(status.statusText == 'timeout') {
				layer.close(index);
				errsoletishi('请求超时！')
			}
		},
	})
}

function mySpeek(src,ceng){
	mySpeekRemove()
	var speek = document.createElement("audio");;
	var str = "../assets/src/hcyy/"
	if(ceng == 1){
		str = "../../assets/src/hcyy/";
	}
	if(ceng == 2){
		str = "../../../assets/src/hcyy/";
	}
	speek.setAttribute("src",str + src + ".wav");
	$("body").append(speek)
	speek.play();
}

function mySpeekRemove(){
	if(document.getElementsByTagName("audio")){
		$("audio").remove();
	}
}

$(function() {
	$(".submit").click(function(){
		mySpeek("正在查询，请稍后",2)
	})
})

iview.lang('en-US');
var law_management = 'http://gzzw.gzegn.gov.cn:82/law_management';
var terminal_management = 'http://103.3.152.111:84/terminal_management/';
var UrbanService = 'https://gzzw.gzegn.gov.cn:84/UrbanService/';
var zhengwuji = 'https://zwzx.anshun.gov.cn:84/zhengwuji/';
var dw_url = 'http://gzzw.gzegn.gov.cn:83/IntegratedQuery';