var isSeachSelf = true;
var login_userCode = '';
var login_userName = '';
var user_name = '';
var user_code = '';
$(function() {
	var dq_url = window.location.href;
	$.ajax({
		type: "post",
		url: "http://gzzw.gzegn.gov.cn:82/bmcx/userInfo",
		async: true,
		timeout: 10000,
		success: function(d) {
			console.log(d);
			if(d.USER_NAME) {
				login_userName = d.USER_NAME;
				login_userCode = d.CARD_NO;
				console.log(login_userName);
				user_name = d.USER_NAME;
				user_code = d.CARD_NO;
				$("#idCard").val(d.CARD_NO);
				$(".idCard").val(d.CARD_NO);
				$('#username').val(d.USER_NAME);
				$('.username').val(d.USER_NAME);
				$.get('http://58.16.65.68:83/sso/login?utype=0&client_id=Y4EZ3IRVR&goto=location.href');
			} else {
				var modek = layer.alert('没有获取到用户信息，请登录后重试！', {
					icon: 5,
					closeBtn: 0
				}, function() {
					layer.close(modek);
					window.location.href = 'http://58.16.65.68:83/sso/login?utype=0&client_id=XXQFH6QUG&goto=' + dq_url;
				});
			}
		},
		error: function(e) {
			console.log(e);
		},
		complete: function(status) { //请求完成后最终执行参数
			if(status == 'timeout') {
				errsoletishi('请求超时！')
			}
		},
	});
	$("#idCard").val(login_userCode);
	$('#username').val(login_userCode);
	$('#password').val('123456');
	$('#change_ps_box').hide();
	$('.query_so').click(function() {
		isSeachSelf = !isSeachSelf;
		$('#change_ps_box').slideToggle(600);
		$($(this)).toggleClass('query_se');
		$('.query_so').text('查他人');
		$('.query_se').text('查自己');
		//查他人的时候，，清空身份证输入框
		$('.query_so').siblings('input').val(login_userCode).attr('disabled', true);
		$('.query_se').siblings('input').val('').attr('disabled', false);
		$('.query_so').parent().siblings('#change_ps_box').find('input').val('123456');
		$('.query_se').parent().siblings('#change_ps_box').find('input').val('');
	});
})