var header_html = '<img class="index_logo" src="../../../assets/img/guohui.png"/>'+
				'<div class="index_titandarea">'+
					'<p>贵州政务服务自动终端系统</p>'+
					'<div class="index_titandarea_area">'+
						'<span>{{nowxuanze}}政务服务中心</span>'+
						'<button @click="areachange()">地区切换</button>'+
					'</div>'+
				'</div>'+
				'<div v-show="showone==true" class="index_login">'+
					'<a href="../../login.html">'+
						'我要登录'+
					'</a>'+	
				'</div>'+
				'<div v-show="showtwo==true" class="index_login" @click="tuichuuser">'+
					'退出登录'+
				'</div>'+
				'<div v-show="showtwo==true" class="index_sheyutime">'+
					'<span style="color: #000;margin-right: 7.5px;">{{shengyutime}}</span>秒'+
				'</div>'+
				'<div v-if="showtwo==true" class="index_perple">'+
					'欢迎{{userinfo.REALNAME}}登录!'+
				'</div>';
$("#public_head").html(header_html);
window.onload = function () {
	document.oncontextmenu = function () { return false; }
	document.onselectstart = function () { return false; }
	document.onselect = function () { return false; }
	
	document.onkeydown = function (key) {
	    if (key.keyCode == 123 && key.ctrlKey) {
	        ft.showDevTools();
	    }
	}
}
