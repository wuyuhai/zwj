var hotItemsVue = new Vue({
	el: '#index_box',
	data: {
		titlearea:'贵州',
		areachangebol: false,
		nowxuanze: '省级',
		shengyutime: 120,
		areas: [],
		userinfo: '',
		showone: true,
		showtwo: false,
		tiems: '',
		
		tisjiconttxt:"",
		list:"",
		obj:"",
	},
	created: function() {
		//				console.log(new Date().toLocaleString('chinese', { hour12: false }).replace(/\//g,"").replace(" ","").replace(/:/g,"")) 				
		this.userinfo = JSON.parse(localStorage.getItem('userinfo'));
		console.log(this.userinfo)
		if(!this.userinfo) {
			window.location.href = "../../new/newlogin.html"
		} else {
			this.showone = false;
			this.showtwo = true
			this.tiemsr()
		}
		console.log(window.location.href)
		localStorage.areaicod = "520000";

		if(localStorage.getItem('areaicodname')) {
			this.nowxuanze = localStorage.getItem('areaicodname');
		} else {
			localStorage.areaicodname = '省级';
		}
		setTimeout(function() {
			//					ftOpenHid(); //开启高拍仪
			clearTimeout();
		}, 10)

	},
	components: {

	},
	methods: {
		retprepage() {
			page_back()
		},
		areachange() {
			this.areachangebol = true;
			if(this.userinfo) {
				this.tiemsr()
			}
		},
		areachangeclose() {
			this.areachangebol = false;
			if(this.userinfo) {
				this.tiemsr()
			}
		},
		clickshicur(e, a, name) {
			console.log(e.currentTarget)
			$(e.currentTarget).addClass('cur');
			$(e.currentTarget).siblings().removeClass('cur');
			if(a == "520555" || a == "520000") {
				this.areas = [];
				this.nowxuanze = $(e.currentTarget).text();
				localStorage.areaicod = a;
				localStorage.areaicodname = $(e.currentTarget).text().replace(/\s+/g, "");
			} else {
				var data = {
					"parentAreaId": a
				}
				var that = this;
				//var re = require('qs'); //创建传输数据对象
				$.ajax(terminal_management + '/workGuide/findAreaInfoList', {
					data: JSON.stringify(data),
					dataType: 'json', //服务器返回json格式数据
					contentType: "application/json",
					timeout: 10000,
					type: 'post', //HTTP请求类型
					success: function(data) {
						//服务器返回响应，根据响应结果，分析是否登录成功；
						console.log(data)
						if(data.code == 200) {
							$(".areaxuanze_kuang_qu ul li").removeClass('cur');
							that.areas = data.data;
							that.areas.unshift({
								"areaid": a,
								"name": name
							})
						} else {
							errsoletishi(data.msg);
						}
					},
					error: function() {
						errsoletishi("请求错误")
					},
					complete: function(status){ //请求完成后最终执行参数
						//console.log(status)
						if(status=='timeout'){
							errsoletishi("请求超时")
						}
					},
				});
			}
			if(this.userinfo) {
				this.tiemsr()
			}
		},
		clickshiqu(e, a) {
			this.nowxuanze = $(e.currentTarget).text();
			$(e.currentTarget).addClass('cur');
			$(e.currentTarget).siblings().removeClass('cur');
			localStorage.areaicod = a;
			localStorage.areaicodname = $(e.currentTarget).text().replace(/\s+/g, "");
			if(this.userinfo) {
				this.tiemsr()
			}
		},
		tuichuuser() {
			localStorage.clear()
			localStorage.areaicod = sessionStorage.getItem("jyareaicod");
			localStorage.areaicodname = sessionStorage.getItem("jyareaicodname");
			this.showone = true;
			this.showtwo = false;
			clearInterval;
			window.location.href = "../../index.html";
		},
		tiemsr() {
			clearInterval(this.tiems);
			var that = this;
			this.shengyutime = 120;
			this.tiems = setInterval(function() {
				that.shengyutime--;
				if(that.shengyutime == 0) {
					clearInterval(this.tiems);
					that.tuichuuser()
//					localStorage.clear()
//					that.showone = true;
//					that.showtwo = false;
//					window.location.href = "../../index.html";
				}
			}, 1000)
		},
		tipzidsure(){
			$(".errsoelts").hide();
		}
	},
	mounted: function() {
		//				chushi();
		if(localStorage.getItem('titlearea')){
			this.titlearea = localStorage.getItem('titlearea');
		}else{
			this.titlearea = '贵州';
		}
		setInterval(function() {
			clearInterval;
			nowtime()
		}, 1000)
	},
})

function nowtime() {
	var myDate = new Date();
	var days = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
//	$(".index_footer").text(myDate.toLocaleString() + " " + days[myDate.getDay()])
}
setInterval(function() {
	clearInterval;
	nowtime()
}, 1000)